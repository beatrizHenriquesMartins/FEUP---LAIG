//série de animações
//deprecated unnecessary class
class ComboAnimation{
    constructor(Animations){
        this.Animations = Animations;
   
    }

    update(deltaTime){
    

    }

    isFinished(){
     
    }

    reset(){
       
    }

}
